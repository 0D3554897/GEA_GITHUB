package com.deltek.enterprise.extensions.xt_ibmctmcntr.java;


import java.sql.SQLException;

import com.deltek.enterprise.system.applicationinterface.ActionInterface;
import com.deltek.enterprise.system.applicationinterface.DEException;
import com.deltek.enterprise.system.applicationinterface.ResultSetInterface;
import com.deltek.enterprise.system.applicationinterface.RowSetInterface;
import com.deltek.enterprise.system.applicationinterface.SqlManager;


public class Xt_CtmcntrLoadContractTypesAction {
	public String sContactDesc;
	public String sContactCd;
	
	public short loadData(ActionInterface actI) throws DEException,SQLException
	{
		
		SqlManager sqlMgr       = actI.getSqlManager(this);
		ResultSetInterface rsI  = actI.getResultSet() ;
		RowSetInterface roI     = rsI.getRowSet();
		try
		{
			String sSelect ="SELECT S_CONTACT_CD, S_CONTACT_DESC FROM S_CNTR_CONTACTS ORDER BY S_CONTACT_CD INTO :sContactCd, :sContactDesc ";
			sqlMgr.SqlPrepareAndExecute(sSelect);
			
			while (sqlMgr.SqlFetchNext())
			{
				roI.addNewRow();
				roI.setStringValue(sContactDesc, "S_CONTACT_DESC");
				roI.setStringValue(sContactCd, "S_CONTACT_CD");			
				roI.setStringValue(sContactCd, "XT_CONTACT_CD");			
		
			}
		}
		finally
		{
			if (sqlMgr != null)
			{
				sqlMgr.close();
				sqlMgr = null;
			}
		}		
		return 0;

	}
	
}
