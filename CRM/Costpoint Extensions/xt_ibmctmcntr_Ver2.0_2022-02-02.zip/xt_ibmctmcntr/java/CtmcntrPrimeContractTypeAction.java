package com.deltek.enterprise.extensions.xt_ibmctmcntr.java;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;


import com.deltek.enterprise.system.applicationinterface.ActionInterface;
import com.deltek.enterprise.system.applicationinterface.DEException;
import com.deltek.enterprise.system.applicationinterface.RSIterator;
import com.deltek.enterprise.system.applicationinterface.ResultSetInterface;
import com.deltek.enterprise.system.applicationinterface.RowSetInterface;
import com.deltek.enterprise.system.applicationinterface.SqlManager;

public class CtmcntrPrimeContractTypeAction   
{
	public String xt_sSetPrimeContrType = "";
	//public String xt_sSetAsideCategoryDesc = "";
	
	public short loadData(ActionInterface actI) throws DEException,SQLException
	{
		
		SqlManager sqlMgr       = actI.getSqlManager(this);
		ResultSetInterface rsI  = actI.getResultSet() ;
		RowSetInterface roI     = rsI.getRowSet();
		ArrayList aSubcPlanList = new ArrayList();	
		String sSubcPlanCdCompare = "";
		RowSetInterface roICompare;
		
	
		try
		{			
			aSubcPlanList.clear();
		    String sMsg = "";
		    
			 int nOrigChldContextRow = rsI.getRowSetContext();								
			 RSIterator rsIter2 = rsI.findInit(RowSetInterface.ROW_Any, RowSetInterface.ROW_MarkDeleted, true);
			 while (rsIter2.next() != RowSetInterface.UNDEFINED_CONTEXT) 
			 {
				 sSubcPlanCdCompare = "";							 
				 roICompare = rsI.getRowSet();
				 			
				 //sSubcPlanCdCompare = roICompare.getStringValue("XT_COST_FEE_CD");
				 sSubcPlanCdCompare = roICompare.getStringValue("XT_PRIME_CONTR_TYPE");
				 aSubcPlanList.add(sSubcPlanCdCompare);					
			 }   				
			 rsI.setRowSetContext(nOrigChldContextRow);

			 
			String sSelect ="SELECT PRIME_CONTR_TYPE " +
							"FROM XT_LIST_PRIME_CONTR_TYPE WHERE SHOW_IN_LOOKUP = 'Y' ORDER BY PRIME_CONTR_TYPE ASC  INTO :xt_sSetPrimeContrType";
							//+ ", :xt_sSetAsideCategoryDesc ";
			sqlMgr.SqlPrepareAndExecute(sSelect);
				
			while (sqlMgr.SqlFetchNext())
			{
				if (! aSubcPlanList.contains(xt_sSetPrimeContrType)) {    
					roI.addNewRow();
					roI.setStringValue(xt_sSetPrimeContrType, "XT_PRIME_CONTR_TYPE");
					//roI.setStringValue(xt_sSetAsideCategoryDesc, "XT_SET_ASIDE_CATEGORY_DESC");					
				}
			}
			
		}
		finally
		{
			if (sqlMgr != null)
			{
				sqlMgr.close();
				sqlMgr = null;
			}
		}		
		return 0;

	}
	
}
