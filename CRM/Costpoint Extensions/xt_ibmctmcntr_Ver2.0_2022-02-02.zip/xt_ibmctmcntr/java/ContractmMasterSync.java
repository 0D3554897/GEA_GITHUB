package com.deltek.enterprise.extensions.xt_ibmctmcntr.java;

import com.deltek.enterprise.system.serverapi.remoteapi.MessageTypes;
import java.sql.SQLException;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.stream.Collectors;
import com.deltek.enterprise.application.common.businesshelper.BusinessWrapper;
import com.deltek.enterprise.system.applicationinterface.ActionInterface;
import com.deltek.enterprise.system.applicationinterface.AppInterface;
import com.deltek.enterprise.system.applicationinterface.DEException;
import com.deltek.enterprise.system.applicationinterface.LoggerInterface;
import com.deltek.enterprise.system.applicationinterface.RSIterator;
import com.deltek.enterprise.system.applicationinterface.ResultSetInterface;
import com.deltek.enterprise.system.applicationinterface.RowSetInterface;
import com.deltek.enterprise.system.applicationinterface.SqlManager;

	public class ContractmMasterSync {
		protected static final String FILECATALOGLABEL = "file catalog";
		protected static final String XT_LOGGING_LOCATION = "XT_LOGGING";
		protected static final String XT_SETTINGS_LOCATION = "XT_SETTINGS";
		
		protected static int initCount = 0;
		
		protected Object appObject;
		protected Object actionObject;

		protected StringBuilder loggerLines = null;
		protected String lastSqlError = null;
		
		protected LoggerInterface logger = null;
		protected boolean haveXTLogging = false;
		protected boolean haveXTLoggingLocation = false;
		protected boolean haveXTLogsMail = false;
		
		protected AppInterface app;
		protected ActionInterface action;
		protected ResultSetInterface resultSet;
		
		protected RowSetInterface rowSet = null;
		protected boolean verboseDebugging = true;
		protected Collator usCollator = null;
		protected DateTimeFormatter logDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withLocale(Locale.US).withZone(ZoneId.of("UTC"));
		
		protected String appAppName = null;
		protected String appUserID = null;
		protected String appID = null;
		protected String entryObjectID = null;
		protected String eventName = null;
		protected String eventSubject = null;
		protected HashMap<String, SqlManager> sqlManagers = null;
		
		protected String debugMessageID = null;
		protected String infoMessageID = null;
		protected String errorMessageID = null;
		
		protected StringBuilder resultBuilder = null;
		static final String FIELD_SEPARATOR = ",";
		static final String idField = "CNTR_ID";
		protected List<ResultSetInterface> xtChildInterfaces = null;
		protected String[] childRsTableNames = {"XT_CNTR_MASTER","XT_CNTR_MOD_GRID","XT_PRIME_CONTR_TYPE","XT_CNTR_MASTER_CONTACT"};
		

		public ContractmMasterSync() {
			usCollator = Collator.getInstance(Locale.US);
	        usCollator.setStrength(Collator.PRIMARY);
	        
	        eventName = null;
			appAppName = null;
			appUserID = null;
			appID = null;
			entryObjectID = null;
			debugMessageID = null;
			infoMessageID = null;
			errorMessageID = null;
			
			sqlManagers = new HashMap<>();
			
			this.debugMessageID = this.errorMessageID = this.infoMessageID = "XT_IBMCTMCNTR_1__MSG";
		}
		
		protected short assignIdIfNeeded() throws DEException, SQLException {
			short returnValue = 0;		
			//auto generate
			String sqlForGettingUsedIDs 		= "SELECT CNTR_ID FROM CNTR_MASTER  WHERE CNTR_ID BETWEEN :sFirstDocID AND :sLastDocID  AND COMPANY_ID = :CP_COMPANY_ID ";
			String settingTableNameForLastId 	= "CNTR_SETTINGS";
			String settingColumnNameForLastId 	= "LAST_CNTR_ID";		
			
			returnValue = BusinessWrapper.assignDocId(resultSet, "CNTR_ID", sqlForGettingUsedIDs, settingTableNameForLastId, settingColumnNameForLastId, false, true);
			
			return returnValue;
		}
		
		protected boolean syncChild(String rsName) throws SQLException,DEException
		{
			String[] parentKeys = new String[]{"CNTR_ID"};
			String[] childKeys = new String[]{"XT_CNTR_ID"};
			
			ResultSetInterface rsChild;
			
			rsChild = resultSet.getChild(rsName);
			
			if (rsChild != null) 
			{
				BusinessWrapper.syncReferencedKeys(rsChild, parentKeys, childKeys);
				return true;
			}
			
			return false;

		}
		
		public short afterRSSave(ResultSetInterface rsI)  {
			String contractID = null; 
			RSIterator iter = null;
			String q = null;
			SqlManager sqlManager = null;
			int rowsDeleted = 0;
			 
			
	 		try {
	 			
	 			initialize(rsI);
	 			
	 			logDebug("afterRSSave - checking for Contract extended records to be deleted");
	 			sqlManager = getSqlManager();
				
	 			try {
	 				 
	 				logDebug("checking rows for deletable records");
	 				
					iter = resultSet.findInit(RowSetInterface.ROW_MarkDeleted, 0, true);
					
		 			while (iter.next() != RowSetInterface.UNDEFINED_CONTEXT) 
		 			{ 
		 				contractID 	= rowSet.getStringValue("CNTR_ID");
		 				if (isBlank(contractID)) {
		 					logDebug("CNTR_ID is blank, skipping child deletions");
		 					continue;
		 				}
		 				
		 				logDebug("processing child deletions for CNTR_ID " + contractID); 
		 				
		 				for(String childTable : childRsTableNames) {
		 					logDebug("child table " + childTable);
		 					q = "DELETE FROM " + childTable + " WHERE CNTR_ID='" + contractID + "'";
		 					sqlManager.SqlPrepareAndExecute(q);
		 					rowsDeleted = sqlManager.SqlGetModifiedRows();
		 					info("deleted " + rowsDeleted + " rows from " + childTable + " (" + childTable + ") for Contract " + contractID);
		 				}
		 			}
		 			
		 			 
		 			
	 			} catch (Exception ex) {
	 				error(ex.getMessage());
	 				error("error while deleting child records for Contract " + contractID);
	 				 
	 			}
	 			 
				return 0;
			}
			catch(Exception ex) {
				warning("error deleting Contract children");
				logError(ex.getClass().getSimpleName());
				logError(ex.getMessage());
				return 3;	
			}
			finally {
				uninitialize();
			}
			
		}
		
		public short validateRS(ResultSetInterface rsI) throws DEException, SQLException {
			short resultFromID = 0;
			String contractID = null; 
			RSIterator iter = null;
			List<ResultSetInterface> allChildren = null;
			String childRsID = null;
			
	 		try {
	 			
	 			initialize(rsI);
	 			
	 			logDebug("validateRS - checking for autogeneration of Contract ID");
	 			String sAutoAssignFl = (String) app.getConstant("CP_CTMSETTINGS_CNTRAUTOASSGFL");	
	 			if (!sAutoAssignFl.equals("Y"))
	 			{
	 				return 0;
	 			}
	 			
	 			//ONLY RETURNS THE OPEN CHILDREN
	 			allChildren = resultSet.getAllChildren();
	 			xtChildInterfaces = allChildren.stream().filter(r -> r.getRSId().startsWith("XT_")).collect(Collectors.toList());
	 			
	 			if (xtChildInterfaces == null || xtChildInterfaces.isEmpty())
	 				return 0;
	 			
	 			iter = resultSet.findInit(RowSetInterface.ROW_New | RowSetInterface.ROW_ChildModified, RowSetInterface.ROW_MarkDeleted, true);
	 				
	 			while (iter.next() != RowSetInterface.UNDEFINED_CONTEXT) 
	 			{ 
	 				contractID 	= rowSet.getStringValue("CNTR_ID");
	 				if (!isBlank(contractID)) {
	 	            	continue;
	 	            }
	 	            
	 	            resultFromID = assignIdIfNeeded();
	 	            
	 				if(resultFromID > 2) {
	 					throw new DEException("failed to assign ID to contract; code " + resultFromID);
	 				}
	 				 
 					contractID = rowSet.getStringValue(idField);
 					logInfo("assigned Contract ID = " + contractID);
 					
 					//now update children
 					for(ResultSetInterface childRS: xtChildInterfaces) {
 						childRsID = childRS.getRSId(); 
 						if(syncChild(childRsID)) {
 							logInfo("updated " + childRsID);
 						}
 					}
 					
	 			}
	 			 
				return 0;
			}
			catch(Exception ex) {
				warning("error while assigning ID to Contract");
				logError(ex.getClass().getSimpleName());
				logError(ex.getMessage());
				return 3;	
			}
			finally {
				uninitialize();
			}
			
		}
		
		 
	 	public boolean isBlank(String s) {
	 		return (null == s || s.isEmpty() || stringsEqual("null",s) || stringsEqual("NULL",s));
	 	}
	 	
	 	public boolean stringsEqual(String string1, String string2) {
	    	return (0 == usCollator.compare(string1, string2));
	    }
	 	
	 	protected void logLevelMessage(Object o, String level) {
			
			if (haveXTLogging) {
				if (null == loggerLines)
					loggerLines = new StringBuilder();
				
				if (isBlank(level))
					level = "D";

				loggerLines.append(level);
				loggerLines.append(" ");
				loggerLines.append(LocalDateTime.now().format(logDateTimeFormatter));
				loggerLines.append("\t:");
				
				loggerLines.append(o);
				loggerLines.append("\r\n");
			}
			else if (null != logger){
				
				switch (level) {
					case "D":
					case "V":
						logger.debug(o);
						break;
						
					case "I":
						logger.info(o);
						break;
									
					case "W":
						logger.warn(o);
						break;
						
					case "E":
						logger.error(o);
						break;
						
					case "F":
						logger.fatal(o);
						break;
		
					default:
						break;
				}
				
			}
		}
		
		public void logInfo(Object o) {
			logLevelMessage(o,"I");
		}
		
		public void logWarning(Object o) {
			logLevelMessage(o,"W");
		}
		
		public void logError(Object o) {
			logLevelMessage(o,"E");
		}
		
		public void logError(Error ex) {
			logLevelMessage(ex.getClass().getSimpleName() + ": " + ex.getMessage(),"Err");
		}
		
		public void logError(Exception ex) {
			logLevelMessage(ex.getClass().getSimpleName() + ": " + ex.getMessage(),"E");
		}
		
		public void logError(Throwable ex) {
			logLevelMessage(ex.getClass().getSimpleName() + ": " + ex.getMessage(),"E");
		}
		
		public void logFatal(Object o) {
			logLevelMessage(o,"F");
		}
		
		public void logDebug(Object o) {

			logLevelMessage(o,"D");
		}

		public void logDebugVerbose(Object o) {
			if (!verboseDebugging)
				return;
			logLevelMessage(o,"V");
		}
		
		 //run as whatever
	    public boolean initialize(Object cpObject) throws DEException {
	    	 
	        try{

	        	incrementInitCount();
	        	
	        	usCollator = Collator.getInstance(Locale.US);
	            usCollator.setStrength(Collator.PRIMARY);
	        	
	        	setCostpointObjects(cpObject);
	        	
	        	logDebug("initialize; verbose=" + verboseDebugging);
	        	
	    		 
	        	logDebug("entry objectID: " + (entryObjectID) + ":@" + (appAppName) + "(" + (appID) + ")");
	        	logDebug("user dir: " + System.getProperty("user.dir"));
	        	logDebug(System.getProperty("java.class.path"));
	            
	        	logDebug("initialized; got appI,logger");
	        	
	        	logInfo("current user=" + appUserID);
	        	        	
	        	if (null != resultSet)
	        		logDebug("resultSet impl = " + resultSet.getClass().getName());
	        	else
	        		logDebug("resultSet is null");
	        	
	        	if (null != rowSet)
	        		logDebug("rowSet impl = " + rowSet.getClass().getName());
	        	else
	        		logDebug("rowSet is null");
	        	
	        	return true;
	        	

	        }
	        catch(Exception ex){
	            if (null != logger)
	            	logError(ex);
	            
	            return false;
	        }
	        
	    }
	    
	    protected void setCostpointObjects(Object cpObject) throws DEException {
	    	
	    	if (null == cpObject) {
	    		throw new DEException("null cp object");
	    	}
	    	
	    	if (cpObject instanceof ActionInterface ) {
	    		
	    		action = (ActionInterface)cpObject;
	    		app = action.getApplication();
	    		resultSet = action.getResultSet();
	    		
	    		entryObjectID = "action." + action.getActionId();
	    		    		
	    	}
	    	else if (cpObject instanceof AppInterface) {
	    		action = null;
	    		app = (AppInterface)cpObject;
	    		resultSet = null;
	    		
	    		entryObjectID = "app." + app.getAppId();
	    		 
	    	}
	    	else if (cpObject instanceof ResultSetInterface) {
	    		resultSet = (ResultSetInterface) cpObject;
	    		action = null;
	    		app = resultSet.getApplication();
	    		
	    		entryObjectID = "rs." + resultSet.getRSId();
	    		
	    	}
	    	else {
	    		throw new DEException("unsupported extension entry type: " + cpObject.getClass().getName());
	    	}
	    	
	    	appObject = app;
	    	actionObject = action;
	    	logger = app.getAppLogger();
	    	
	    	appID = app.getAppId();
	    	appUserID = app.getUserId();
	    	appAppName = app.getAppName();
	    	
	    	
	    	if (null != resultSet) {
	    		rowSet = resultSet.getRowSet();
	    	}
	    	 	    	
	    }
	    
	    public void uninitialize() {
	    	
	    	try {
	    	
		    	logDebug("uninitialize...");
		 	
		    	if (null != loggerLines) {
		    		flushLogging();
		    	}
		    	
		    	eventName = null;
		    	eventSubject = null;
		    	
		    	for(SqlManager sqm:sqlManagers.values()) {
		    		sqm.close();
		    	}
		    	
		    	sqlManagers.clear();
		     
	    	}
	    	catch (Exception ex) {
	    		if (null != logger) {
					logger.error("error while uninitializing extension");
				}
			}
	    	
	    }
	     protected void flushLogging() {
	    	String d = null;
	
	    	//if debugging is enabled, write the cached extension log activity to the debug log
	    	if (null != logger && logger.isDebugEnabled()) {
	    	
	    		d = loggerLines.toString();
	    		loggerLines.setLength(0);
	    		
	    		logger.debug(d);
	    	}
	    	
	    	 
	    }
	    
	    protected static void incrementInitCount() {
	    	initCount++;
	    }
	    protected String getDatedfilename(String prefix, String suffix) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_hh.mm.ss");
			formatter.setTimeZone(TimeZone.getDefault());
			return prefix + "_" + formatter.format(Calendar.getInstance().getTime()) + suffix;
		}
	    
	    public short info(String message) {
			logInfo(message);
			
			if (!isBlank(infoMessageID))
				resultSet.addRSMessage(infoMessageID, MessageTypes.INFORMATION, new String[] {message} );
			
			return MessageTypes.INFORMATION;
		}
		
		public short warning(String message) {
			logWarning(message);
			
			if (!isBlank(errorMessageID))
				resultSet.addRSMessage(errorMessageID, MessageTypes.WARNING, new String[] {message} );
			
			return MessageTypes.WARNING;
		}
		
		public short error(String message) {
			logError(message);
			
			if (!isBlank(errorMessageID))
				resultSet.addRSMessage(errorMessageID, MessageTypes.ERROR, new String[] {message} );
			
			return MessageTypes.ERROR;
		}
		
		public short lineError(String message) {
			logError(message);
			
			if (!isBlank(errorMessageID))
				resultSet.addLineMessage(errorMessageID, MessageTypes.ERROR, new String[] {message} );
			
			return MessageTypes.ERROR;
		}
		
		public short fatal(String message) {
			logFatal(message);
			
			if (!isBlank(errorMessageID))
				resultSet.addRSMessage(errorMessageID, MessageTypes.FATAL, new String[] {message} );
			
			return MessageTypes.FATAL;
		}
		
		public short notify(short level, String message) {
			logLevelMessage(level,message);
			
			if (!isBlank(errorMessageID))
				resultSet.addRSMessage(errorMessageID, level, new String[] {message} );
			
			return level;
		} 
	    
	    public SqlManager getSqlManager() throws DEException {
	    	return getSqlManager(null);
	    }
		
		
	    
	    public SqlManager getSqlManager(String ds) throws DEException {
	    	SqlManager sqm = null;
	    	
	    	if (isBlank(ds)) {
	    		ds = "DATA";
	    	}
	    	else {
	    		ds = ds.toUpperCase(Locale.US);
	    	}
	    	
	    	logDebug("getSqlManager: " + (ds));
	    	
	    	sqm = sqlManagers.getOrDefault(ds, app.getSqlManager(ds, null));
	    	
	    	logInfo("database backend (" + ds + " = " + sqm.getBackEnd());
	    	
	    	sqlManagers.put(ds, sqm);
	    	
	    	return sqm;
	    }
	    
	}
