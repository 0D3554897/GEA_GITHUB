package com.deltek.enterprise.extensions.xt_ibmctmcntr.java;

 
import com.deltek.enterprise.system.applicationinterface.AppInterface;
import com.deltek.enterprise.system.applicationinterface.DEException;
import com.deltek.enterprise.system.applicationinterface.LoggerInterface;
import com.deltek.enterprise.system.applicationinterface.ResultSetInterface;
import com.deltek.enterprise.system.applicationinterface.RowSetInterface;
import com.deltek.enterprise.system.serverapi.remoteapi.MessageTypes;

public class SetDefaults {
	LoggerInterface logger = null;
	AppInterface app = null;
	RowSetInterface rowSet = null;
	static final int CP_OK = 0;
	
	public short validateRS(ResultSetInterface rsI) throws DEException {
		
		String value = null;
				
		try {
			
			app = rsI.getApplication();
			logger = app.getAppLogger();
			rowSet = rsI.getRowSet();
			
			log("copyFields");
			
			log("Copying Fields...");
			
			//value = rowSet.getStringValue("XT_SUBCNTR_PLAN_STAT_CD_RESTRICT");
			value = "U";
			rowSet.setStringValue(value, "PROPOSAL_REC_FL");
			
			log("Copied Fields");
			
			return CP_OK;

        }
    	catch(Exception ex) { //catches ALL exceptions
    		log("failed to export data");
	        log(ex.getMessage());
    	}
		finally {
			
		}

		return MessageTypes.ERROR;
	}
	
	void log(String message) {
		logger.info(message);
	}
	
}
